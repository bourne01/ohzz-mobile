<template>
    <div>
        Oops!未能找到你所访问的网页！
    </div>
</template>

<script>
export default {
  
}
</script>

<style lang="scss" scoped>

</style>

